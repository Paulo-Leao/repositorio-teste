const { initializeApp, cert, getApps } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');

const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
};

// Inicializa Firebase com as credenciais seguras (variaveis de ambiente)
if (!getApps().length) {
    initializeApp({
        credential: cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
        })
    });
}

const db = getFirestore();

exports.handler = async (event) => {
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 204, headers, body: '' };
    }

    // So aceita POST
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, headers, body: 'Method Not Allowed' };
    }

    try {
        const { email, passwordProvided, passwordLength } = JSON.parse(event.body || '{}');

        // Validacao basica no servidor
        if (!email || !passwordProvided) {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'Dados invalidos' }) };
        }

        // Salva no Firestore
        await db.collection('usuarios').add({
            email: email,
            passwordProvided: true,
            passwordLength: Number(passwordLength || 0),
            timestamp: new Date().toISOString(),
            ip: event.headers['x-forwarded-for'] || 'desconhecido'
        });

        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ success: true })
        };

    } catch (error) {
        console.error('Erro ao salvar dados:', error);

        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Erro interno' })
        };
    }
};
